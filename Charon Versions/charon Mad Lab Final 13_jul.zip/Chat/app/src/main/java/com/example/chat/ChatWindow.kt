package com.example.chat

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.gson.Gson
import com.scottyab.aescrypt.AESCrypt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.lang.Exception
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

class ChatWindow : AppCompatActivity() {
    lateinit var chatRecycler: RecyclerView
    lateinit var messagebox: EditText
    lateinit var sendbtn: Button
    lateinit var talking_with: TextView
    lateinit var messageAdapter: messageAdapter
    lateinit var messageList: ArrayList<Message>

    lateinit var dbref: DatabaseReference

    var receiverRoom: String? = null
    var senderRoom: String? = null //unique room for the pair of sender and receiver

    //encryption
    val key = byteArrayOf(12, 91, 55,  43, -21, -101, -60, 96, 48, 6, -52, 87, 39, -65, 73, -67)
    lateinit var cipher: Cipher
    lateinit var decipher: Cipher
    lateinit var secretKey: SecretKeySpec

    
    var keys : String = "abdef"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_window)



        chatRecycler = findViewById(R.id.chat)
        messagebox = findViewById(R.id.chat_message)
        sendbtn = findViewById(R.id.send)
        talking_with = findViewById(R.id.chat_user)
        dbref = FirebaseDatabase.getInstance("https://charon-39c64-default-rtdb.asia-southeast1.firebasedatabase.app/")
                .getReference()


        val username = intent.getStringExtra("username")
        val receiver_uid = intent.getStringExtra("uid")
        val sender_uid = FirebaseAuth.getInstance().currentUser?.uid

        senderRoom = receiver_uid + sender_uid
        receiverRoom = sender_uid + receiver_uid

        talking_with.text = username.toString()
        //supportActionBar?.title = username
        messageList = ArrayList()
        messageAdapter = messageAdapter(this, messageList)
        chatRecycler.layoutManager = LinearLayoutManager(this)
        chatRecycler.adapter = messageAdapter

        cipher = Cipher.getInstance("AES")
        decipher = Cipher.getInstance("AES")

        secretKey = SecretKeySpec(key, "AES")

        //val fcmToken = FirebaseMessaging.getInstance().getToken()

        sendbtn.setOnClickListener {
            //add message to db

            var message = messagebox.text.toString()

            if(message == ""){
                Toast.makeText(this, "Type a message", Toast.LENGTH_SHORT).show()
            }
            //encrypting string before sending to db
            else {
                var aesMessage = encryptMessage(message)
//            var decr =  AESCrypt.decrypt(keys, aesMessage)
//            Toast.makeText(baseContext, "$decr", Toast.LENGTH_SHORT).show()

                //var decrmsg = decryptMessage(aesMessage) //should crash -- problem in decrypt function
//            Toast.makeText(
//                        baseContext, "$decrmsg",
//                        Toast.LENGTH_SHORT
//            ).show()

                //reading message here so use as model input

                val messageobj = Message(
                    aesMessage,
                    sender_uid
                ) // create Message object with encrypted string -->success
                //aesMessage stores the encrypted string, get decryption right then replace message with aesMessage

                //create a node of chats
                dbref.child("chats").child(senderRoom!!).child("messages").push()
                    .setValue(messageobj)
                    .addOnSuccessListener {
                        dbref.child("chats").child(receiverRoom!!).child("messages").push()
                            .setValue(messageobj)
                    }
                messagebox.setText("")
                //the encrypted message was sent to the server

                //creating notification title and message
//            val title = "Charon"
//            val notifMessage = "you have an anonymous message"
//            pushNotif(
//                notifData(title,message),
//            )
            }
        }

        //to add data to recycler view

        dbref.child("chats").child(senderRoom!!).child("messages").addValueEventListener(object :
            ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                messageList.clear()
                for (postSnapshot in snapshot.children) {
                    var msg = postSnapshot.getValue(Message::class.java)
                    //encrypted message object being read here
                    //var encrmsg = msg?.message.toString() // can access string
//                    var decr =  AESCrypt.decrypt(keys,encrmsg )
//                    msg?.message = decr
                    try {
                        msg?.message = decryptMessage(msg)
                    }catch (e : Exception){
//                        Toast.makeText(
//                        baseContext, "$e",
//                        Toast.LENGTH_LONG
//            ).show()
                    }

                    messageList.add(msg!!)

                }
                chatRecycler.scrollToPosition(messageList.size - 1)
                //to send notification for receiving a message
                //NotificationCompat.Builder()
                messageAdapter.notifyDataSetChanged()

            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }


        })
    }


    private fun encryptMessage(message: String): String {
        //converting str to byte format
//        var temp = message
//
//        var encryptedByte: ByteArray // output of the encryption to be stored here
//
//        cipher.init(Cipher.ENCRYPT_MODE, secretKey)
//        encryptedByte = cipher.doFinal(temp.toByteArray())
//
//        var encryptedMessage = encryptedByte.toString()
//
//        return encryptedMessage

        var encrypted : String = AESCrypt.encrypt(keys,message)
        return encrypted

    }

    private fun decryptMessage(encrmsg: Message?): String {

//        var temp = encrmsg// getting string from Message object
//        var encryptedByte: ByteArray? = encrmsg?.toByteArray() // converted string to byte format
//
//        var decrStr : String? = encrmsg
//        var decryptedByte: ByteArray
//
//        decipher.init(Cipher.DECRYPT_MODE, secretKey)
//
//        decryptedByte = decipher.doFinal(encryptedByte)
//        decrStr = decryptedByte.toString()
//        return decrStr
        var decrypted : String = AESCrypt.decrypt(keys, encrmsg?.message)
        return decrypted


    }


    private fun sendNotification(notif: pushNotif) = CoroutineScope(Dispatchers.IO).launch {
        try {
            val response = retrofitInstance.api.postNotification(notif)
            if (response.isSuccessful) {
                Toast.makeText(
                    baseContext, "${Gson().toJson(response)}",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                if (response.isSuccessful) {
                    Toast.makeText(
                        baseContext, "${response.errorBody()}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

        } catch (e: Exception) {
            Toast.makeText(
                baseContext, "$e",
                Toast.LENGTH_SHORT
            ).show()
        }

    }
}