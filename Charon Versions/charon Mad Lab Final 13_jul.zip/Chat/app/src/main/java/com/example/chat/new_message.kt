package com.example.chat

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class new_message : AppCompatActivity() {
    lateinit var users: RecyclerView
    lateinit var user_list: ArrayList<User>
    lateinit var adapter: UserAdapter
    lateinit var dbref: DatabaseReference
    lateinit var search_user : EditText
    lateinit var search_button : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_message)
        //to present a list of users


        users = findViewById(R.id.users)
        users.layoutManager = LinearLayoutManager(this)
        users.hasFixedSize()
        user_list = arrayListOf<User>()

        search_user = findViewById(R.id.search_user)
        search_button = findViewById(R.id.search_btn)

        var found = 0
        //users.adapter = adapter
        search_button.setOnClickListener {

            val searchUsername = search_user.text.toString()+"@xyz.com"
            //Toast.makeText(this@new_message,searchUsername, Toast.LENGTH_SHORT).show()

            dbref = FirebaseDatabase.getInstance("https://charon-39c64-default-rtdb.asia-southeast1.firebasedatabase.app/")
                .getReference()
            dbref.child("users").addValueEventListener(object : ValueEventListener { // getting the users
                override fun onDataChange(snapshot: DataSnapshot) {
                    user_list.clear()
                    if (snapshot.exists()) {
                        for (userSnapshot in snapshot.children) {
                            val currentUser = userSnapshot.getValue(User::class.java)
                            if (currentUser != null && currentUser.uid != FirebaseAuth.getInstance().currentUser?.uid && currentUser.username == searchUsername ) {
                                currentUser.username = currentUser.username?.removeSuffix("@xyz.com")

                                found = 1
                                user_list.add(currentUser)
                                break

                            }
                        }
                        if(found == 1){
                            users.adapter = UserAdapter(user_list)
                        }
                        else{
                            Toast.makeText(this@new_message,"User Not Found", Toast.LENGTH_SHORT).show()
                        }
                        //users.adapter = UserAdapter(user_list)
                        //adapter.notifyDataSetChanged()
                    }
                }
                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }
            })
        }

    }
}
