package com.example.chat

data class pushNotif (val data : notifData, val to : String){

}