package com.example.chat

import android.content.IntentSender

class Message {
    lateinit var message : String
    var senderid : String? = null

    constructor(){}
    constructor(message: String?,senderid : String?){
        if (message != null) {
            this.message = message
        }
        this.senderid = senderid
    }
}