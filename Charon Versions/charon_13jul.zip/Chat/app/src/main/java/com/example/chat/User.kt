package com.example.chat

class User {
    var username : String? = null
    var uid : String? = null
    constructor(){}
    constructor(username: String?, uid: String?){
        this.username = username
        this.uid = uid
    }
}