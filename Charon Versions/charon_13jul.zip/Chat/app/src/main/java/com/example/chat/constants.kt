package com.example.chat

class constants {
    companion object{
        const val BASE_URL = "https://fcm.googleapis.com"
        const val SERVER_KEY = "BBZwlKVKm5mupueJATLWP1v3d2DdHwIvP32gVcd4FL1y0xCJmPCmM6-TVMr0i42cJkrd6qdEFjtdK06mlWQlElk"
        const val CONTENT_TYPE = "application/json"
    }
}