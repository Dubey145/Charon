package com.example.chat


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class Login : AppCompatActivity() {

    private lateinit var user_login : EditText
    private lateinit var password_login: EditText

    private lateinit var login : Button
    private lateinit var auth : FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        user_login = findViewById<EditText>(R.id.user_login)
        password_login = findViewById<EditText>(R.id.password_login)
        login = findViewById(R.id.login)
        auth = FirebaseAuth.getInstance()

        login.setOnClickListener {
            var username =  user_login.text.toString() + "@xyz.com"
            val pass = password_login.text.toString()
            login(username,pass)
        }
    }

    private fun login(username: String, pass: String) {
        auth.signInWithEmailAndPassword(username, pass)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this@Login,"welcome back", Toast.LENGTH_LONG).show()
                    val intent = Intent(this,messages::class.java)
                    startActivity(intent)
                } else {
                    // If sign in fails, display a message to the user.
                    Toast.makeText(this@Login,"user does not exist", Toast.LENGTH_LONG).show()
                }
            }
    }
//private fun perform_login(){
//    var temp = user_login.text.toString()
//    val user = temp+"@xyz.com"
//    val pass = password_login.text.toString()
//    FirebaseAuth.getInstance().signInWithEmailAndPassword(user,pass)
//        //.addOnCompleteListener()
//
//}
}