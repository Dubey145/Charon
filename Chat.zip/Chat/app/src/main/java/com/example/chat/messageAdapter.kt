package com.example.chat

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth

class messageAdapter(val context : Context,val MessageList : ArrayList<Message>):RecyclerView.Adapter<RecyclerView.ViewHolder>(){

    val item_rcv : Long = 1
    val item_sent : Long  = 2
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
    if(viewType == 1){
        val view : View = LayoutInflater.from(parent.context).inflate(R.layout.recv,parent,false)
        return receiveViewHolder(view)
    }
    else{
        val view : View = LayoutInflater.from(parent.context).inflate(R.layout.sent,parent,false)
        return sentViewHolder(view)
    }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val currentMessage = MessageList[position]

        if(holder.javaClass == sentViewHolder::class.java){
            //use sentviewholder
            val viewHolder = holder as sentViewHolder
            holder.sentmessage.text = currentMessage.message
        }
        else{
            //use receive view holder
            val viewholder = holder as receiveViewHolder
            holder.recvmessage.text = currentMessage.message

        }
    }

    override fun getItemId(position: Int): Long {
        val currentMessage = MessageList[position]
        if(FirebaseAuth.getInstance().currentUser?.uid.equals(currentMessage.senderid)){
        //sender is the user logged in
            return item_sent
        }
        else{
            return item_rcv
        }

    }

    override fun getItemCount(): Int {
        return MessageList.size
    }
    class sentViewHolder(itemView: View) :RecyclerView.ViewHolder(itemView){
        val sentmessage = itemView.findViewById<TextView>(R.id.sent_message)
    }
    class receiveViewHolder(itemView: View) :RecyclerView.ViewHolder(itemView){
        val recvmessage = itemView.findViewById<TextView>(R.id.recv_message)
    }
}