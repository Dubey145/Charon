package com.example.chat

data class notifData(val title : String, val message : String) {


}