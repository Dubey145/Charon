package com.example.chat

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import com.google.firebase.auth.FirebaseAuth

class messages : AppCompatActivity() {

    lateinit var logout : Button
    lateinit var new_chat : Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_messages)

        //to check if a user is logged into firebase
        val uid = FirebaseAuth.getInstance().uid
        if(uid == null) {
            //no user
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }

        logout = findViewById(R.id.logout)
        new_chat = findViewById(R.id.New_Chat)

        logout.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            val intent = Intent(this,MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK.or(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
        new_chat.setOnClickListener {
            //new message activity
            val intent = Intent(this,new_message::class.java)
            startActivity(intent)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item?.itemId){
            R.id.menu_new_message -> {

        }
            R.id.menu_sign_out -> {
            FirebaseAuth.getInstance().signOut()
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }
        }
        return super.onOptionsItemSelected(item)
    }
    //creating a top right "new chat | logout"
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.navmenu,menu)
        return super.onCreateOptionsMenu(menu)
    }
}