package com.example.chat

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class new_message : AppCompatActivity() {
    lateinit var users: RecyclerView
    lateinit var user_list: ArrayList<User>
    lateinit var adapter: UserAdapter
    lateinit var dbref: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_message)
        //to present a list of users

        users = findViewById(R.id.users)
        users.layoutManager = LinearLayoutManager(this)
        users.hasFixedSize()
        user_list = arrayListOf<User>()

        //users.adapter = adapter

        dbref = FirebaseDatabase.getInstance("https://charon-39c64-default-rtdb.asia-southeast1.firebasedatabase.app/")
                .getReference()
        dbref.child("users").addValueEventListener(object : ValueEventListener { // getting the users
            override fun onDataChange(snapshot: DataSnapshot) {
                user_list.clear()
                if (snapshot.exists()) {
                    for (userSnapshot in snapshot.children) {
                        val currentUser = userSnapshot.getValue(User::class.java)
                        if (currentUser != null && currentUser.uid != FirebaseAuth.getInstance().currentUser?.uid) {
                            currentUser.username = currentUser.username?.removeSuffix("@xyz.com")

                            user_list.add(currentUser)
                        }
                    }
                    users.adapter = UserAdapter(user_list)
                    //adapter.notifyDataSetChanged()
                }
            }
            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        })
    }
}
