package com.example.chat


import android.Manifest
import android.app.KeyguardManager
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CancellationSignal
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import com.google.firebase.auth.FirebaseAuth

class Login : AppCompatActivity() {

    private lateinit var user_login : EditText
    private lateinit var password_login: EditText

    private lateinit var login : Button
    private lateinit var auth : FirebaseAuth

    private var cancellationSignal : CancellationSignal? = null
    private var authFlag = 0
    private val authenticationCallback: BiometricPrompt.AuthenticationCallback
        get() =
            @RequiresApi(Build.VERSION_CODES.P)
            object : BiometricPrompt.AuthenticationCallback(){
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                    super.onAuthenticationError(errorCode, errString)
                    notifyUser("Authentication error : $errString")
                }

                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                    super.onAuthenticationSucceeded(result)
                    authFlag = 1
                    startLogin()
                    notifyUser("Authentication successful")
                }
            }


    @RequiresApi(Build.VERSION_CODES.P)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        user_login = findViewById<EditText>(R.id.user_login)
        password_login = findViewById<EditText>(R.id.password_login)
        login = findViewById(R.id.login)
        auth = FirebaseAuth.getInstance()

        login.setOnClickListener {

            authFlag = 0
            var username =  user_login.text.toString() + "@xyz.com"
            val pass = password_login.text.toString()
            // AUTHENTICATE BIOMETRICS HERE

            if(authFlag == 0) {
                authenticateBiometrics()
            }
            if (authFlag == 1){
                //for emulator demo just set auth flag to 1 and comment authFlag in login
                login(username,pass)
            }
//            else{
//                notifyUser("Authenticate First!!!")
//            }


        }
    }

    @RequiresApi(Build.VERSION_CODES.P)
    private fun authenticateBiometrics() {
        checkBiometrics()
        val biometricPrompt = BiometricPrompt.Builder(this)
            .setTitle("Authenticate Fingerprint")
            .setDescription("This app uses fingerprint as a level of authentication")
            .setNegativeButton("cancel",this.mainExecutor,DialogInterface.OnClickListener { dialog, which -> notifyUser("Authentication Cancelled")
            }).build()


        biometricPrompt.authenticate(getCancellationSignal(),mainExecutor,authenticationCallback)

    }

    private fun getCancellationSignal() : CancellationSignal{
        cancellationSignal = CancellationSignal()
        cancellationSignal?.setOnCancelListener {
            notifyUser("Authentication was cancelled by the user")
        }
        return cancellationSignal as CancellationSignal
    }
    private fun checkBiometrics(): Boolean{

        val keyguardManager = getSystemService(KEYGUARD_SERVICE) as KeyguardManager

        if(!keyguardManager.isKeyguardSecure){
            notifyUser("Fingerprint authentication has not been enabled in settings")
            return false
        }
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.USE_BIOMETRIC) != PackageManager.PERMISSION_GRANTED){
            notifyUser("Fingerprint authentication permission is not enabled")
            return false
        }
        return if(packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)){
            true
        }else {
            true
        }
    }
    private fun startLogin(){
        var username =  user_login.text.toString() + "@xyz.com"
        val pass = password_login.text.toString()
        if (authFlag == 1){
            login(username,pass)
        }
        else{
            notifyUser("error logging in")
        }
    }
    private fun login(username: String, pass: String) {
        if (username.isEmpty() || pass.isEmpty()) {
            Toast.makeText(
                baseContext, "fields can't be empty",
                Toast.LENGTH_SHORT
            ).show()
            return
        }
        auth.signInWithEmailAndPassword(username, pass)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    password_login.text = null
                    Toast.makeText(this@Login,"welcome back", Toast.LENGTH_LONG).show()
                    val intent = Intent(this,messages::class.java)
                    startActivity(intent)
                } else {
                    // If sign in fails, display a message to the user.
                    Toast.makeText(this@Login,"incorrect details", Toast.LENGTH_LONG).show()
                }
            }
    }
    private fun notifyUser(userMessage : String){
        Toast.makeText(this,userMessage, Toast.LENGTH_LONG).show()
    }
//private fun perform_login(){
//    var temp = user_login.text.toString()
//    val user = temp+"@xyz.com"
//    val pass = password_login.text.toString()
//    FirebaseAuth.getInstance().signInWithEmailAndPassword(user,pass)
//        //.addOnCompleteListener()
//
//}
}