package com.example.chat

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ValueEventListener

class UserAdapter(val userList: ArrayList<User>): RecyclerView.Adapter<UserAdapter.userViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): userViewHolder {
        val view : View = LayoutInflater.from(parent.context).inflate(R.layout.user_card,parent,false)
        return userViewHolder(view)
    }

    override fun onBindViewHolder(holder: userViewHolder, position: Int) {
        val currentuser = userList[position]
        holder.txtname.text = currentuser.username
        holder.itemView.setOnClickListener {
            val intent = Intent(it.context,ChatWindow::class.java)
            intent.putExtra("username",currentuser.username)
            intent.putExtra("uid",currentuser.uid)
            it.context.startActivity(intent)
        }

    }

    override fun getItemCount(): Int {
        return userList.size
    }
    class userViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){
        val txtname: TextView = itemView.findViewById(R.id.username_usercard)

    }
}